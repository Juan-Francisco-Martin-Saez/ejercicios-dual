'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');

// Ejecuta sin modificaciones el script OCR original.
async function runOCR(file, { reuse = false, outputDir = 'output/ocr' } = {}) {
  const abs = path.resolve(file);
  const base = path.parse(abs).name;

  const dir = path.resolve(outputDir);
  await fs.mkdir(dir, { recursive: true });

  const dest = path.join(dir, base + '.ocr.json');

  if (reuse) {
    const candidates = [
      dest,
      path.join(__dirname, 'output', base + '.ocr.json'),
      path.resolve(base + '.ocr.json'),
      path.join(path.dirname(abs), base + '.ocr.json')
    ];

    let raw;

    for (const candidate of candidates) {
      try {
        raw = JSON.parse(await fs.readFile(candidate, 'utf8'));
        break;
      } catch (e) {
        if (e.code !== 'ENOENT') throw e;
      }
    }

    if (!raw) {
      throw new Error(
        'No existe resultado OCR reutilizable: ' +
        candidates.join(' | ')
      );
    }

    if (typeof raw.text !== 'string' || !raw.text.trim()) {
      throw new Error('OCR JSON sin campo text');
    }

    // Mantener una copia en el directorio definitivo.
    await fs.writeFile(
      dest,
      JSON.stringify(raw, null, 2),
      'utf8'
    );

    return raw;
  }

  await fs.access(abs);

  // El script original escribe en cwd.
  // Se ejecuta en output/ocr/ para mantener su lógica.
  await new Promise((resolve, reject) => {
    const proc = spawn(
      process.execPath,
      [
        path.join(__dirname, 'originales', 'vastai-ocr-test.mjs'),
        abs
      ],
      {
        cwd: dir,
        env: process.env,
        stdio: 'inherit'
      }
    );

    proc.once('error', reject);

    proc.once('exit', (code, signal) => {
      if (code === 0) {
        resolve();
      } else {
        reject(
          new Error('OCR falló: ' + code + ' ' + (signal || ''))
        );
      }
    });
  });

  const raw = JSON.parse(await fs.readFile(dest, 'utf8'));

  if (typeof raw.text !== 'string' || !raw.text.trim()) {
    throw new Error('OCR sin texto');
  }

  return raw;
}

function parseBlocks(rawText, sourceFile) {
  if (typeof rawText !== 'string' || !rawText.trim()) {
    throw new Error('OCR vacío');
  }

  const pages = rawText.replace(/\r\n/g, '\n').split('<PAGE>');
  const result = [];
  let page = 0;

  for (const part of pages) {
    if (!part.trim()) continue;

    page++;

    const markers = [
      ...part.matchAll(/<BLOCK>([^\n]*?)<FORK>/g)
    ];

    const entries = markers.length
      ? markers.map((m, i) => ({
        head: m[1],
        text: part.slice(
          m.index + m[0].length,
          i + 1 < markers.length
            ? markers[i + 1].index
            : part.length
        ).trim(),
        ordinal: i + 1
      }))
      : [{
        head: 'text',
        text: part.trim(),
        ordinal: 1
      }];

    for (const entry of entries) {
      if (!entry.text) continue;

      const type =
        entry.head.match(/^[^\[<]+/)?.[0]?.trim() || 'unknown';

      const coords =
        entry.head.match(/\[([^\]]+)\]/)?.[1]
          ?.split(',')
          .map(Number) || null;

      const id = 'ocr_' + crypto
        .createHash('sha256')
        .update(
          sourceFile + '\0' +
          page + '\0' +
          entry.ordinal + '\0' +
          entry.text
        )
        .digest('hex')
        .slice(0, 24);

      result.push({
        id,
        source: path.basename(sourceFile),
        page,
        block: entry.ordinal,
        type,
        coords:
          coords?.length === 4 &&
            coords.every(Number.isFinite)
            ? coords
            : null,
        text: entry.text
      });
    }
  }

  if (!result.length) {
    throw new Error('No se encontraron bloques OCR');
  }

  return result;
}

module.exports = { runOCR, parseBlocks };