'use strict';

const OpenAI = require('openai');
const { ChromaClient } = require('chromadb');
const { retry } = require('./openai-service.js');

const batchSize = () =>
  Math.max(
    1,
    Math.min(100, Number(process.env.CHROMA_BATCH_SIZE || 20) || 20)
  );

async function prepareVectors(blocks) {
  const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
  });

  const model =
    process.env.EMBEDDING_MODEL || 'text-embedding-3-small';

  const result = [];

  for (let i = 0; i < blocks.length; i += batchSize()) {
    const chunk = blocks.slice(i, i + batchSize());

    const response = await retry(() =>
      client.embeddings.create({
        model,
        input: chunk.map(b => b.text),
        encoding_format: 'float'
      })
    );

    const vectors = response.data
      .slice()
      .sort((a, b) => a.index - b.index)
      .map(x => x.embedding);

    if (vectors.length !== chunk.length) {
      throw new Error('Cantidad de vectores incorrecta');
    }

    chunk.forEach((b, j) => {
      result.push({
        ...b,
        embedding: vectors[j],
        metadata: {
          source: b.source,
          page: b.page,
          block: b.block,
          type: b.type,
          keywords: b.keywords.join(' | '),
          coords: b.coords ? JSON.stringify(b.coords) : '',
          embedding_model: model
        }
      });
    });

    console.log(
      `Embeddings ${result.length}/${blocks.length}`
    );
  }

  return result;
}

async function storeVectors(rows) {
  const url = new URL(
    process.env.CHROMA_URL || 'http://localhost:8000'
  );

  const client = new ChromaClient({
    host: url.hostname,
    port: Number(
      url.port || (url.protocol === 'https:' ? 443 : 80)
    ),
    ssl: url.protocol === 'https:'
  });

  // Los embeddings ya están generados mediante OpenAI.
  // No utilizar el motor predeterminado de ChromaDB.
  const collection = await client.getOrCreateCollection({
    name: process.env.CHROMA_COLLECTION || 'ocr_documents',
    embeddingFunction: null
  });

  for (let i = 0; i < rows.length; i += batchSize()) {
    const chunk = rows.slice(i, i + batchSize());

    await collection.upsert({
      ids: chunk.map(b => b.id),
      documents: chunk.map(b => b.text),
      embeddings: chunk.map(b => b.embedding),
      metadatas: chunk.map(b => b.metadata)
    });

    console.log(
      `ChromaDB ${Math.min(i + chunk.length, rows.length)}/${rows.length}`
    );
  }

  return rows.length;
}

module.exports = {
  prepareVectors,
  storeVectors
};