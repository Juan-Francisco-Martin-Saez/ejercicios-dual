
'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const { storeVectors } = require('./vector-service.js');

async function main() {
  const filename = process.argv[2];

  if (!filename) {
    throw new Error(
      'Uso: node --env-file=.env import-chroma.js archivo.chroma-ready.json'
    );
  }

  const file = path.resolve(filename);
  const rows = JSON.parse(await fs.readFile(file, 'utf8'));

  if (!Array.isArray(rows) || rows.length === 0) {
    throw new Error('No hay registros para importar');
  }

  for (const [i, row] of rows.entries()) {
    if (
      typeof row.id !== 'string' ||
      typeof row.text !== 'string' ||
      !Array.isArray(row.embedding) ||
      !row.embedding.length ||
      !row.embedding.every(Number.isFinite) ||
      !row.metadata ||
      typeof row.metadata !== 'object' ||
      Array.isArray(row.metadata)
    ) {
      throw new Error(`Registro inválido: ${i + 1}`);
    }
  }

  console.log(`Registros preparados: ${rows.length}`);

  const inserted = await storeVectors(rows);

  console.log(`Inserción completada: ${inserted} registros`);
}

main().catch(error => {
  console.error('ERROR:', error.message);
  process.exitCode = 1;
});
