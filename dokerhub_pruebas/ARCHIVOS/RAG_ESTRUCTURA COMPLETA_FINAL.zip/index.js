
'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');

const { runOCR, parseBlocks } = require('./ocr-service.js');
const { extractKeywords } = require('./openai-service.js');
const { prepareVectors, storeVectors } = require('./vector-service.js');

async function main() {
  const args = process.argv.slice(2);
  const filename = args.find(a => !a.startsWith('--'));

  if (!filename) {
    throw new Error(
      'Uso: node --env-file=.env index.js input/documento.pdf [--reuse-ocr] [--prepare-only]'
    );
  }

  const input = path.resolve(filename);
  const base = path.parse(filename).name;

  // Directorios permanentes de salida
  const output = path.join(__dirname, 'output');
  const ocrDir = path.join(output, 'ocr');
  const keywordsDir = path.join(output, 'keywords');
  const chromaDir = path.join(output, 'chroma');

  // Crear automáticamente las carpetas necesarias
  await Promise.all([
    fs.mkdir(ocrDir, { recursive: true }),
    fs.mkdir(keywordsDir, { recursive: true }),
    fs.mkdir(chromaDir, { recursive: true })
  ]);

  // Guardar JSON en su directorio correspondiente
  const save = async (directory, suffix, obj) => {
    const file = path.join(directory, base + suffix);

    await fs.writeFile(
      file,
      JSON.stringify(obj, null, 2),
      'utf8'
    );

    return file;
  };

  // FASE 1: OCR
  const raw = await runOCR(input, {
    reuse: args.includes('--reuse-ocr'),
    outputDir: ocrDir
  });

  const blocks = parseBlocks(raw.text, path.basename(filename));

  await save(ocrDir, '.blocks.json', blocks);

  console.log(`Bloques: ${blocks.length}`);

  // FASE 2: Extracción de keywords
  const enriched = await extractKeywords(blocks);

  await save(keywordsDir, '.keywords.json', enriched);

  // FASE 3: Preparación de datos para ChromaDB
  const rows = await prepareVectors(enriched);

  const chromaFile = await save(
    chromaDir,
    '.chroma-ready.json',
    rows
  );

  // FASE 4: Inserción opcional en ChromaDB
  const preparedOnly = args.includes('--prepare-only');

  if (!preparedOnly) {
    await storeVectors(rows);
  }

  console.log(
    `Listo: ${path.relative(__dirname, chromaFile)}` +
    (preparedOnly
      ? ' (sin insertar en ChromaDB)'
      : ' (insertado en ChromaDB)')
  );
}

main().catch(e => {
  console.error('ERROR:', e.message);
  process.exitCode = 1;
});