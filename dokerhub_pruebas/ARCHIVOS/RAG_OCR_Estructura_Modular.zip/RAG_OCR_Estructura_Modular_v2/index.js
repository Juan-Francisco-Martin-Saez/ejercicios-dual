'use strict';
const fs=require('node:fs/promises');const path=require('node:path');
const {runOCR,parseBlocks}=require('./ocr-service.js');
const {extractKeywords}=require('./openai-service.js');
const {prepareVectors,storeVectors}=require('./vector-service.js');
async function main(){
 const args=process.argv.slice(2);const filename=args.find(a=>!a.startsWith('--'));
 if(!filename)throw new Error('Uso: node --env-file=.env index.js input/documento.pdf [--reuse-ocr] [--prepare-only]');
 const input=path.resolve(filename);const output=path.join(__dirname,'output');await fs.mkdir(output,{recursive:true});
 const base=path.parse(filename).name;const save=async(suffix,obj)=>fs.writeFile(path.join(output,base+suffix),JSON.stringify(obj,null,2),'utf8');
 const raw=await runOCR(input,{reuse:args.includes('--reuse-ocr'),outputDir:output});
 const blocks=parseBlocks(raw.text,path.basename(filename));await save('.blocks.json',blocks);console.log(`Bloques: ${blocks.length}`);
 const enriched=await extractKeywords(blocks);await save('.keywords.json',enriched);
 const rows=await prepareVectors(enriched);await save('.chroma-ready.json',rows);
 const preparedOnly=args.includes('--prepare-only');if(!preparedOnly)await storeVectors(rows);
 console.log(`Listo: output/${base}.chroma-ready.json${preparedOnly?' (sin insertar en ChromaDB)':' (insertado en ChromaDB)'}`);
}
main().catch(e=>{console.error('ERROR:',e.message);process.exitCode=1;});
