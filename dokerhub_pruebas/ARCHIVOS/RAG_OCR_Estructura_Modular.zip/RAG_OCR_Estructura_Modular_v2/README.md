# RAG OCR modular v2 — estructura solicitada

## Estructura
- `index.js`: coordina input PDF -> OCR -> OpenAI -> embeddings -> Chroma -> output JSON.
- `ocr-service.js`: ejecuta el **script original intacto** `originales/vastai-ocr-test.mjs` en un subproceso. Se conservan `/ready`, `/ocr`, puertos, parámetros, validación y ficheros `.ocr.txt` / `.ocr.json`.
- `openai-service.js`: recicla `originales/openai-service-original.js` para extraer palabras clave por bloque.
- `vector-service.js`: embeddings sobre **texto del bloque** (no solo keywords) e inserción en ChromaDB con `upsert`.
- `input/`: PDF; `output/`: OCR original, bloques, palabras clave, JSON con vectores.
- `bocetos/`: **las dos capturas originales adjuntas**, sin modificar.
- `query.js`: consulta RAG opcional, reciclada de la primera versión.

## Uso (PowerShell)
```powershell
npm install
Copy-Item .env.example .env
# Rellenar .env (no subir a Git)
Copy-Item "C:\ruta\documento.pdf" "input\documento.pdf"
node --env-file=.env index.js "input/documento.pdf" --prepare-only
```
Sin `--prepare-only` se intenta insertar en ChromaDB (servidor aparte). Para reutilizar OCR existente, coloca `documento.ocr.json` en `output/` y ejecuta:
```powershell
node --env-file=.env index.js "input/documento.pdf" --reuse-ocr --prepare-only
```
`--reuse-ocr` también busca `<nombre>.ocr.json` en el directorio actual o junto al PDF. No necesita acceder al PDF si ya existe JSON OCR.

## Salidas
- `output/documento.ocr.txt` y `.ocr.json` al ejecutar OCR real.
- `output/documento.blocks.json`: páginas, tipos, coordenadas, texto.
- `output/documento.keywords.json`: palabras clave por bloque.
- `output/documento.chroma-ready.json`: vectores y metadatos listos para ChromaDB.

## Notas
- Tablas OCR HTML se conservan como bloque completo, sin perder celdas.
- El archivo JSON de vectores puede ser grande. No contiene secretos.
- El servicio OCR original se conserva sin modificaciones. Si su nombre o API cambia, ajustar únicamente el adaptador.
- El ZIP original incluía secretos: **no se copian `.env` ni `OPENAI_KEY.txt`**.
- No se ha podido verificar una ejecución real de OpenAI, Vast.ai o ChromaDB desde este entorno. Se han comprobado sintaxis y extracción local de bloques.
- El código de consulta es opcional y no se invoca en la ingesta.
